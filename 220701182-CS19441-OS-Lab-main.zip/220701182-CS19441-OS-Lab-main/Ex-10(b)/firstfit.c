#include<stdio.h> 
#include<conio.h>
#define max 25
void main()
int frag[max],b[max],f[max].ij.nb.nf,temp; static int bf[max],ff[max]:
clrscr();
printf("\nEnter the number of blocks:");
scanf("%d", &nb);
printf("Enter the number of files:"); scanf("%d",&nf);
printf("\nEnter the size of the blocks-n"); for(i=1;i<=n;i++)
printf("Block %d"); scanf("%d",&b[i]);
printf("Enter the size of the files:-\n"); for(i=1;i<=nf;i++)
printf("File %d:"i scanf("%d",&ffil):
for(i=1;iconf;i++)
for(j=1;j<=ab;j++)
if(b[j]!=1)
temp=b[j]-f[i];
if(temp>=0)
break;
frag[i]=temp;
printf("\nFile_nocFile_size:\tBlock_no:tBlock_size:\tFragment"); for(i=1;iconf;i++) printf("\n%d\t\t%d\t\t%dgy%d\t\t%d",i.f[i].ff[i]b[ff[i]].frag[i]);
getch();
